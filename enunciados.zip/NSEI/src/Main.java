
public class Main {

	public static void main(String[] args) {
		Array objArray = new Array();
		enu1 objenu1 = new enu1();
		
		//objArray.listarNumeros();
		objenu1.ExibirNomes();

	}

}
