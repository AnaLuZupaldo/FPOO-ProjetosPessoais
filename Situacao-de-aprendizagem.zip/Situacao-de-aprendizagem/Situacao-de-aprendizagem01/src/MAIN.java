import java.util.Scanner;
public class MAIN {

	public static void main(String[] args) {
	
		Scanner objScanner = new Scanner(System.in);
		
		DadosPessoais objDadosPessoais = new DadosPessoais();
		
		DadosContato objDadosContato = new DadosContato();
		
		DadosEndereco objDadosEndereco = new DadosEndereco();
		
		System.out.println("BEM VINDO AO CADASTRO DA EMPRESA SYSTEC");
		
		 System.out.println("DIGITE UM NOME:");
		objDadosPessoais.setNome(objScanner.next());
		
		System.out.println("DIGITE SEU SOBRENOME ");
		objDadosPessoais.setsobreNome(objScanner.next());
	
		System.out.println("DIGITE A SUA DATA DE NASCIMENTO COMPLETA");
		objDadosPessoais.setdataNascimento(objScanner.next());
	
	    System.out.println("DIGITE SEU G�NERO");
	    objDadosPessoais.setgenero(objScanner.next());
	
	    System.out.println("DIGITE SEU EMAIL");
	    objDadosContato.setEmail(objScanner.next());
	   
	    System.out.println("DIGITE SEU TELEFONE");
	    objDadosContato.setTelefone(objScanner.next());
	    
	    System.out.println("DIGITE SEU CEP");
	    objDadosEndereco.setCep(objScanner.next());
	    
	    System.out.println("DIGITE SEU LOUGADORO");
	    objDadosEndereco.setLogadouro(objScanner.next());
	    
	    System.out.println("DIGITE O N�MERO DA CASA");
	    objDadosEndereco.setNumero(objScanner.next());
	    
	    System.out.println("DIGITE O BAIRRO");
	    objDadosEndereco.setBairro(objScanner.next());
	    
	    System.out.println("DIGITE A SUA CIDADE");
	    objDadosEndereco.setCidade(objScanner.next());
	    
	    System.out.println("DIGITE O ESTADO");
	    objDadosEndereco.setEstado (objScanner.next());
	    
	    System.out.println("OBRIGADA, CADASTRO REALIZADO COM SUCESSO");
	}

}
